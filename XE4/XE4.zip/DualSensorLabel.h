//---------------------------------------------------------------------------

#ifndef DualSensorLabelH
#define DualSensorLabelH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include "Define.h"

//---------------------------------------------------------------------------
class PACKAGE TDualSensorLabel : public TCustomLabel
{
private:

    //--------------------------------
    // Sensor Led 
    TColor          FSenLineColor;
    TColor          FSenOnColor;
    TColor          FSenOffColor;
    TSensorLedType  FSenType;
    int             FSenWidth;
    int             FSenHeight;
    int             FSenRectRound;
    int             FSenSpace;
    bool            FSenLEDImage;   ///< true�� ��� �⺻ Default LED Image��� 

    Graphics::TBitmap* pBmpSenOn;
    Graphics::TBitmap* pBmpSenOff;
    Graphics::TBitmap* pBmpSenDisable;
    
    //--------------------------------
    bool            FSenOutLine;
    TColor          FSenOutLineColor;
    int             FSenOutLineRound;
    int             FSenOutSpace;
    //--------------------------------
    bool            FSenOnL;        ///< true�� ��� On Color, false�� ��� Off Color�� ���� 
    bool            FSenOnR;        ///< true�� ��� On Color, false�� ��� Off Color�� ���� 
    bool            FSenVisibleL;   ///< ���� ���� ���̱�     
    bool            FSenVisibleR;   ///< ���� ���� ���̱� 
    
    //--------------------------------
    // Title



    
    //--------------------------------

    Graphics::TBitmap* pBitmapBase;

    //--------------------------------

    void            __fastcall SetSenLineColor(TColor v);
    void            __fastcall SetSenOnColor(TColor v);
    void            __fastcall SetSenOffColor(TColor v);
    void            __fastcall SetSenType(TSensorLedType  v);
    void            __fastcall SetSenWidth(int    v);
    void            __fastcall SetSenHeight(int    v);
    void            __fastcall SetSenRectRound(int v);
    void            __fastcall SetSenOnL(bool   v);
    void            __fastcall SetSenOnR(bool   v);
    void            __fastcall SetSenSpace(int    v);
    void            __fastcall SetSenLEDImage(bool v);
    void            __fastcall SetSenVisibleL(bool v);
    void            __fastcall SetSenVisibleR(bool v);

    void            __fastcall SetSenOutLine(  v);
    void            __fastcall SetSenOutLineColor(TColor    v);
    void            __fastcall SetSenOutLineRound(int       v);
    void            __fastcall SetSenOutSpace(int       v);

protected:
    virtual void     __fastcall Loaded(void);                    ///< Loaded �Լ� �������̵�.
    virtual void     __fastcall SetEnabled(bool Value);          ///< SetEnabled �Լ� �������̵�.

    void            __fastcall DrawSensorL();
    void            __fastcall DrawSensorR();
    void            __fastcall DrawTitle();
    void            __fastcall DrawOutLine();

public:
    __fastcall TDualSensorLabel(TComponent* Owner);
    virtual __fastcall ~TDualSensorLabel();
    virtual void     __fastcall Paint();                         ///< Paint �Լ� �������̵�.

__published:

    __property  TColor          SenLineColor    = { read = FSenLineColor,   write = SetSenLineColor,    default = clBlack };
    __property  TColor          SenOnColor      = { read = FSenOnColor,     write = SetSenOnColor,      default = clLime };
    __property  TColor          SenOffColor     = { read = FSenOffColor,    write = SetSenOffColor,     default = clSilver };
    __property  TSensorLedType  SenType         = { read = FSenType,        write = SetSenType,         default = slCircle };
    __property  int             SenWidth        = { read = FSenWidth,       write = SetSenWidth,        default = 15 };
    __property  int             SenHeight       = { read = FSenHeight,      write = SetSenHeight,       default = 15 };
    __property  int             SenRectRound    = { read = FSenRectRound,   write = SetSenRectRound,    default = 3  };
    __property  bool            SenOnL          = { read = FSenOnL,         write = SetSenOnL,          default = false };     ///< true�� ��� On Color, false�� ��� Off Color�� ���� 
    __property  bool            SenOnR          = { read = FSenOnR,         write = SetSenOnR,          default = false };     ///< true�� ��� On Color, false�� ��� Off Color�� ���� 
    __property  int             SenSpace        = { read = FSenSpace,       write = SetSenSpace,        default = 5 };
    __property  bool            SenLEDImage     = { read = FSenLEDImage,    write = SetSenLEDImage,     default = true };
    __property  bool            SenVisibleL     = { read = FSenVisibleL,    write = SetSenVisibleL,     default = true };
    __property  bool            SenVisibleR     = { read = FSenVisibleR,    write = SetSenVisibleR,     default = true };

    __property  bool            SenOutLine      = { read = FSenOutLine,     write = SetSenOutLine,      default = true };
    __property  TColor          SenOutLineColor = { read = FSenOutLineColor,write = SetSenOutLineColor, default = clBlack };;
    __property  int             SenOutLineRound = { read = FSenOutLineRound,write = SetSenOutLineRound, default = 0 };
    __property  int             SenOutSpace     = { read = FSenOutSpace,    write = SetSenOutSpace,     default = 5 };

    //---------------------------------------
    __property Width            = {default=200};
    __property Height           = {default=24};
    __property Align            = {default=0};
    __property Alignment        = {default=taCenter};
    __property Anchors          = {default=3};
    //__property AutoSize         = {default=false};
    __property BiDiMode;
    __property Caption          = {default=0};
    //__property Color = {default = (TColor)0xA53E1E};
    __property Constraints;
    __property DragCursor       = {default=-12};
    __property DragKind         = {default=0};
    __property DragMode         = {default=0};
    __property EllipsisPosition = {default=0};
    __property Enabled          = {default=1};
    __property FocusControl;
    __property Font;
    __property GlowSize         = {default=0};
    __property ParentBiDiMode   = {default=1};
    __property ParentColor      = {default=0};
    __property ParentFont       = {default=0};
    __property ParentShowHint   = {default=1};
    __property PopupMenu;
    __property ShowAccelChar    = {default=1};
    __property ShowHint;
    __property Touch;
    __property Transparent      = {default = true};
    __property Layout           = {default=0};
    __property Visible          = {default=1};
    __property WordWrap         = {default=0};
    __property StyleElements    = {default=7};
    __property Color            = {default=clBtnFace};
    __property OnClick;
    __property OnContextPopup;
    __property OnDblClick;
    __property OnDragDrop;
    __property OnDragOver;
    __property OnEndDock;
    __property OnEndDrag;
    __property OnGesture;
    __property OnMouseActivate;
    __property OnMouseDown;
    __property OnMouseMove;
    __property OnMouseUp;
    __property OnMouseEnter;
    __property OnMouseLeave;
    __property OnStartDock;
    __property OnStartDrag;

};
//---------------------------------------------------------------------------
#endif
