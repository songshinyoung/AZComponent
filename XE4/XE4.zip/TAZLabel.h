//---------------------------------------------------------------------------

#ifndef TAZLabelH
#define TAZLabelH
//---------------------------------------------------------------------------
#include <SysUtils.hpp>
#include <Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
//---------------------------------------------------------------------------
class PACKAGE TAZLabel : public TLabel
{
private:
protected:
public:
    __fastcall TAZLabel(TComponent* Owner);
__published:
};
//---------------------------------------------------------------------------
#endif
