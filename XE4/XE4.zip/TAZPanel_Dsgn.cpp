//---------------------------------------------------------------------------

#include <System.hpp>
#pragma hdrstop
USEFORM("AZNumShape_Dsgn.cpp", fmAZNumShapeEditor);
USEFORM("Common\frmNumPad_AZ.cpp", fmNumPad_AZ);
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Package source.
//---------------------------------------------------------------------------


#pragma argsused
extern "C" int _libmain(unsigned long reason)
{
    return 1;
}
//---------------------------------------------------------------------------
